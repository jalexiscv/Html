<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Read the service account credentials
$serviceAccountPath = __DIR__ . '/../service-account.json';
if (!file_exists($serviceAccountPath)) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Service account file not found',
        'path' => $serviceAccountPath
    ]);
    exit;
}

$serviceAccountJson = file_get_contents($serviceAccountPath);
$serviceAccount = json_decode($serviceAccountJson, true);

if (!$serviceAccount) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Invalid service account JSON',
        'path' => $serviceAccountPath
    ]);
    exit;
}

// Get the request body
$requestData = json_decode(file_get_contents('php://input'), true);
if (!$requestData) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request data']); 
    exit;
}

// Configuration
$endpoint = "us-east5-aiplatform.googleapis.com"; 
$locationId = "us-east5";
$projectId = "anssible"; 
$modelId = "claude-3-7-sonnet";
$method = "rawPredict";

// Create JWT token
$now = time();
$token = [
    'iss' => $serviceAccount['client_email'],
    'scope' => 'https://www.googleapis.com/auth/cloud-platform',
    'aud' => 'https://oauth2.googleapis.com/token',
    'exp' => $now + 3600,
    'iat' => $now
];

// Sign the JWT
$jwt = generateJWT($token, $serviceAccount['private_key']);

// Get access token using JWT
$tokenUrl = 'https://oauth2.googleapis.com/token';
$tokenData = [
    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
    'assertion' => $jwt
];

$ch = curl_init($tokenUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to get access token',
        'response' => $response
    ]);
    exit;
}

$tokenResponse = json_decode($response, true);
$accessToken = $tokenResponse['access_token'];

// Prepare the API request data
$apiRequestData = [
    'anthropic_version' => 'vertex-2023-10-16',
    'messages' => $requestData['messages'],
    'max_tokens' => $requestData['max_tokens'],
    'temperature' => $requestData['temperature'],
    'top_p' => $requestData['top_p'],
    'top_k' => $requestData['top_k']
]; 

// Make the API request
$url = "https://{$endpoint}/v1/projects/{$projectId}/locations/{$locationId}/publishers/anthropic/models/{$modelId}:{$method}";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($apiRequestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'Content-Type: application/json; charset=utf-8'
]);

// Enable verbose debugging
curl_setopt($ch, CURLOPT_VERBOSE, true);
$verbose = fopen('php://temp', 'w+');
curl_setopt($ch, CURLOPT_STDERR, $verbose);

// Execute the request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);

// Get verbose debug information
rewind($verbose);
$verboseLog = stream_get_contents($verbose);
fclose($verbose);

curl_close($ch);

// Handle the response
if ($httpCode === 200) {
    $responseData = json_decode($response, true);
    
    // Log the full response for debugging
    error_log("Claude API Response: " . print_r($responseData, true));
    
    if (isset($responseData['content'])) {
        echo json_encode([
            'success' => true,
            'response' => $responseData['content']
        ]);
    } else {
        echo json_encode([
            'error' => 'Unexpected response format',
            'response' => $responseData,
            'debug_info' => [
                'request_data' => $apiRequestData,
                'curl_info' => curl_getinfo($ch),
                'verbose_log' => $verboseLog
            ]
        ]);
    }
} else {
    http_response_code($httpCode);
    echo json_encode([
        'error' => 'API request failed',
        'httpCode' => $httpCode,
        'curlError' => $curlError,
        'response' => $response,
        'debug_info' => [
            'request_data' => $apiRequestData,
            'verbose_log' => $verboseLog
        ]
    ]);
}

// Helper function to generate JWT
function generateJWT($payload, $key) {
    $header = [
        'typ' => 'JWT',
        'alg' => 'RS256'
    ];
    $segments = [];
    $segments[] = base64url_encode(json_encode($header));
    $segments[] = base64url_encode(json_encode($payload));
    $signing_input = implode('.', $segments);
    $signature = '';
    openssl_sign($signing_input, $signature, $key, OPENSSL_ALGO_SHA256);
    
    $segments[] = base64url_encode($signature);
    
    return implode('.', $segments);
}

// Helper function for base64url encoding
function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
?>