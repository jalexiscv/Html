document.addEventListener('DOMContentLoaded', () => {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const typingIndicator = document.getElementById('typing-indicator');

    // Configuration
    const config = {
        endpoint: "us-east5-aiplatform.googleapis.com",
        locationId: "us-east5",
        projectId: "anssible",
        modelId: "claude-3-7-sonnet",
        method: "rawPredict"
    };

    function addMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
        
        if (Array.isArray(content)) {
            // Handle array of message parts
            const text = content
                .filter(part => part.type === 'text')
                .map(part => part.text)
                .join('');
            messageDiv.textContent = text;
        } else {
            // Handle simple string messages (user input)
            messageDiv.textContent = content;
        }
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function showTypingIndicator() {
        typingIndicator.style.display = 'block';
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function hideTypingIndicator() {
        typingIndicator.style.display = 'none';
    }

    async function sendMessage(message) {
        const requestData = {
            anthropic_version: "vertex-2023-10-16",
            max_tokens: 4096,
            temperature: 0.7,
            top_p: 0.95,
            top_k: 40,
            messages: [
                {
                    role: "user",
                    content: message
                }
            ]
        };

        try {
            showTypingIndicator();
            
            const response = await fetch('/tests/gpt/api/chat.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestData)
            }); 

            if (!response.ok) {
                throw new Error('Network response was not ok');
            } 

            const data = await response.json();
            hideTypingIndicator();
            
            if (data.error) {
                console.error('API Error:', data);
                addMessage('Error: ' + (data.error.message || 'An error occurred while processing your request.'), false);
            } else if (data.response) {
                addMessage(data.response, false);
            }
        } catch (error) {
            console.error('Error:', error);
            hideTypingIndicator();
            addMessage('Sorry, there was an error processing your request.', false);
        }
    }

    // Event Listeners
    sendButton.addEventListener('click', () => {
        const message = userInput.value.trim();
        if (message) {
            addMessage(message, true);
            sendMessage(message);
            userInput.value = '';
        }
    });

    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendButton.click();
        }
    });
});
